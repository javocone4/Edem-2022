def reto17():
  tupla = (2, 4, 3, 5, 4, 6, 7, 8, 6, 1)
  print(tupla[3:6])
  print(tupla[:6])
  print(tupla[5:])
  print(tupla[:])
  print(tupla[2::2])
  print(tupla[::4])
  print(tupla[9::-1])

reto17()